package com.mockito.string;

public class StringOps
{
	StringService service;
	public StringOps(StringService service)
	{
		this.service=service;
	}
	public String ConcatString(String a,String b)
	{
		return service.ConcatString(a, b);
	}
	public boolean isSubstring(String a,String b)
	{
		return service.isSubstring(a, b);
	}
	public boolean isEqual(String a,String b)
	{
		return service.isEqual(a, b);
	}
	public int StringLength(String a)
	{
		return service.StringLength(a);
	}

}
