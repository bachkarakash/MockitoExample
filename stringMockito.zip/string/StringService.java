package com.mockito.string;

public interface StringService 
{
	public String ConcatString(String a,String b);
	public boolean isSubstring(String a,String b);
	public boolean isEqual(String a,String b);
	public int StringLength(String a);

}
