package com.mockito.string;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

public class StringOpsTest 
{
	StringOps strObj=null;
	StringService service = Mockito.mock(StringService.class);
	@Before
	public void setUp()
	{
		this.strObj = new StringOps(service);
	}

	@Test
	public void test() 
	{
		Mockito.when(service.ConcatString("ABC", "XYZ")).thenReturn("ABCXYZ");
		assertEquals("ABCXYZ",strObj.ConcatString("ABC", "XYZ"));
		Mockito.verify(service).ConcatString("ABC","XYZ");
		//fail("Not yet implemented");
	}
	@Test
	public void test1() 
	{
		Mockito.when(service.isSubstring("ABC", "AB")).thenReturn(true);
		assertEquals(true,strObj.isSubstring("ABC", "AB"));
		Mockito.verify(service).isSubstring("ABC","AB");
		//fail("Not yet implemented");
	}
	@Test
	public void test2() 
	{
		Mockito.when(service.isSubstring("ABC", "ABC")).thenReturn(true);
		assertEquals(true,strObj.isSubstring("ABC", "ABC"));
		Mockito.verify(service).isSubstring("ABC","ABC");
		//fail("Not yet implemented");
	}
	@Test
	public void test3() 
	{
		Mockito.when(service.StringLength("ABCDE")).thenReturn(5);
		assertEquals(5,strObj.StringLength("ABCDE"));
		Mockito.verify(service).StringLength("ABCDE");
		//fail("Not yet implemented");
	}

}
